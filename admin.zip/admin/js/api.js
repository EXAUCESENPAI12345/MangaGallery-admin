/* Manga Gallery Admin - API client */
(function(){
"use strict";
const CONFIG={
  baseUrl: window.MANGA_GALLERY_API_URL || "https://YOUR-BACKEND-DOMAIN/api",
  accessKey:"manga_gallery_access_token",
  refreshKey:"manga_gallery_refresh_token"
};
function storage(){return localStorage;}
function token(){return storage().getItem(CONFIG.accessKey)||"";}
function setTokens(a,r,remember){const s=remember?localStorage:sessionStorage;s.setItem(CONFIG.accessKey,a||"");if(r)s.setItem(CONFIG.refreshKey,r);}
function clear(){localStorage.removeItem(CONFIG.accessKey);localStorage.removeItem(CONFIG.refreshKey);sessionStorage.removeItem(CONFIG.accessKey);sessionStorage.removeItem(CONFIG.refreshKey);}
async function request(path,options={}){
  const url=CONFIG.baseUrl.replace(/\/$/,"")+"/"+String(path).replace(/^\//,"");
  const headers=Object.assign({"Accept":"application/json"},options.headers||{});
  if(options.body!==undefined && !(options.body instanceof FormData)) headers["Content-Type"]="application/json";
  const t=token(); if(t) headers.Authorization="Bearer "+t;
  const res=await fetch(url,{...options,headers});
  let body=null; try{body=await res.json();}catch(_){body={};}
  if(res.status===401 && path!=="/auth/login" && !options._retry){
    const rt=localStorage.getItem(CONFIG.refreshKey)||sessionStorage.getItem(CONFIG.refreshKey);
    if(rt){
      try{
        const rr=await fetch(CONFIG.baseUrl.replace(/\/$/,"")+"/auth/refresh",{method:"POST",headers:{Authorization:"Bearer "+rt,Accept:"application/json"}});
        const rb=await rr.json();
        if(rr.ok && rb.access_token){
          const target=localStorage.getItem(CONFIG.accessKey)?localStorage:sessionStorage;
          target.setItem(CONFIG.accessKey,rb.access_token);
          return request(path,{...options,_retry:true});
        }
      }catch(_){ }
    }
    clear();
  }
  if(!res.ok){throw new Error(body?.message||body?.error?.message||`Erreur API (${res.status})`);}
  if(Array.isArray(body)) return {items:body,total:body.length,total_pages:1,data:body};
  if(body && body.data && typeof body.data==='object') return Object.assign({},body.data,body);
  return body;
}
async function get(path,params={},options={}){const qs=new URLSearchParams();Object.entries(params||{}).forEach(([k,v])=>{if(v!==undefined&&v!==null&&v!=="")qs.set(k,v)});return request(path+(qs.toString()?"?"+qs.toString():""),{...options,method:"GET"});}
async function send(method,path,data,options={}){return request(path,{...options,method,body:data===undefined?undefined:(data instanceof FormData?data:JSON.stringify(data))});}
window.API={get,post:(p,d,o)=>send("POST",p,d,o),put:(p,d,o)=>send("PUT",p,d,o),patch:(p,d,o)=>send("PATCH",p,d,o),delete:(p,o)=>send("DELETE",p,undefined,o),setTokens,clearTokens:clear,getToken:token,config:CONFIG};
window.api=window.API;
})();
