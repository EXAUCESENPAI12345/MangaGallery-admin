/*==================================
MANGA GALLERY
ADMIN DASHBOARD
==================================*/

const usersCount =
document.getElementById("users-count");

const mangasCount =
document.getElementById("mangas-count");

const chaptersCount =
document.getElementById("chapters-count");

const commentsCount =
document.getElementById("comments-count");

const recentActivity =
document.getElementById("recent-activity");

const latestMangas =
document.getElementById("latest-mangas");

const latestUsers =
document.getElementById("latest-users");

const statisticsChart =
document.getElementById("statistics-chart");

const logoutButton =
document.getElementById("logout-button");

const currentDate =
document.getElementById("current-date");


/*==================================
LOAD DASHBOARD
==================================*/

async function loadDashboard(){
  try{
    const response=await window.API.get("/statistics/");
    const stats=response.statistics||response.data?.statistics||response;
    if(usersCount) usersCount.textContent=stats.users??0;
    if(mangasCount) mangasCount.textContent=stats.mangas??0;
    if(chaptersCount) chaptersCount.textContent=stats.chapters??0;
    if(commentsCount) commentsCount.textContent=stats.comments??0;
  }catch(error){ console.error(error); if(typeof showError==="function") showError("Impossible de charger les statistiques."); }
}


/*==================================
RENDER
==================================*/

function renderDashboard(data){

if(!data){

return;

}

/*

Les informations seront
affichées ici à partir
des données du backend.

*/

}

/*==================================
LOGOUT
==================================*/

logoutButton.addEventListener(

"click",

()=>{

/*

Le backend déconnectera ici
l'administrateur.

*/

});


/*==================================
CURRENT DATE
==================================*/

function updateCurrentDate(){

const now = new Date();

currentDate.textContent =

now.toLocaleDateString(

"fr-FR",

{

weekday:"long",

day:"numeric",

month:"long",

year:"numeric"

}

);

}


/*==================================
CHART
==================================*/

function initializeChart(){

/*

Le graphique sera créé ici
à partir des données
envoyées par le backend.

*/

}


/*==================================
START
==================================*/

document.addEventListener(

"DOMContentLoaded",

()=>{

updateCurrentDate();

loadDashboard();

initializeChart();

if(window.lucide){

lucide.createIcons();

}

});