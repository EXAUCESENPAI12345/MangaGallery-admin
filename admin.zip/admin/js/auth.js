/* Manga Gallery Admin - authentication */
"use strict";
function saveAuth(data,remember){
  const target=remember?localStorage:sessionStorage;
  target.setItem("manga_gallery_access_token",data.access_token||"");
  if(data.refresh_token) target.setItem("manga_gallery_refresh_token",data.refresh_token);
  if(data.user) target.setItem("manga_gallery_user",JSON.stringify(data.user));
}
function isAuthenticated(){return !!window.API?.getToken?.();}
async function login(username,password,remember){
  const response=await fetch((window.API.config.baseUrl).replace(/\/$/,"")+"/auth/login",{method:"POST",headers:{"Content-Type":"application/json","Accept":"application/json"},body:JSON.stringify({username,password})});
  const body=await response.json().catch(()=>({}));
  if(!response.ok || !body.success) throw new Error(body.message||"Identifiants incorrects");
  saveAuth(body,remember);
  return true;
}
async function verifySession(){
  if(!isAuthenticated()) return false;
  try{const r=await window.API.get("/auth/verify");const u=r.user||r.data?.user;if(u) sessionStorage.setItem("manga_gallery_user",JSON.stringify(u));return true;}catch(e){return false;}
}
async function currentUser(){const r=await window.API.get("/auth/me");return r.user||r.data?.user||null;}
async function protectPage(roles=["admin"]){
  if(!isAuthenticated()){window.location.href="login.html";throw new Error("Authentification requise");}
  try{const u=await currentUser();if(!u || (u.role!=="admin" && u.role!=="super_admin")){window.location.href="login.html";throw new Error("Accès administrateur requis");}return u;}catch(e){window.location.href="login.html";throw e;}
}
async function secureLogout(){try{await window.API.post("/auth/logout",{});}catch(_){ }finally{clearTokens();window.location.href="login.html";}}
function clearTokens(){window.API?.clearTokens?.();localStorage.removeItem("manga_gallery_user");sessionStorage.removeItem("manga_gallery_user");}
window.isAuthenticated=isAuthenticated;window.login=login;window.verifySession=verifySession;window.protectPage=protectPage;window.secureLogout=secureLogout;window.clearTokens=clearTokens;window.currentUser=currentUser;
