/*
==================================
MANGA GALLERY
LOGIN
==================================
*/


/*
==================================
INITIALIZE
==================================
*/

document.addEventListener(

    "DOMContentLoaded",

    initializeLogin

);


/*
==================================
INITIALIZE LOGIN
==================================
*/

async function initializeLogin() {

    if (

        window.lucide

    ) {

        lucide.createIcons();

    }

    bindEvents();

    await checkSession();

}


/*
==================================
CHECK SESSION
==================================
*/

async function checkSession() {

    try {

        if (

            !isAuthenticated()

        ) {

            return;

        }

        const valid = await verifySession();

        if (

            valid

        ) {

            window.location.href =

                "index.html";

        }

        else {

            clearTokens();

        }

    }

    catch (

        error

    ) {

        clearTokens();

    }

}


/*
==================================
BIND EVENTS
==================================
*/

function bindEvents() {

    document

        .getElementById(

            "login-form"

        )

        .addEventListener(

            "submit",

            handleLogin

        );

    document

        .getElementById(

            "toggle-password"

        )

        .addEventListener(

            "click",

            togglePassword

        );

}

/*
==================================
HANDLE LOGIN
==================================
*/

async function handleLogin(

    event

) {

    event.preventDefault();

    const button = document.getElementById(

        "login-button"

    );

    const loader = document.getElementById(

        "login-loader"

    );

    const errorBox = document.getElementById(

        "login-error"

    );

    errorBox.classList.remove(

        "active"

    );

    errorBox.textContent = "";

    button.disabled = true;

    loader.style.display = "flex";

    try {

        const username = document

            .getElementById(

                "username"

            )

            .value

            .trim();

        const password = document

            .getElementById(

                "password"

            )

            .value;

        const remember = document

            .getElementById(

                "remember-me"

            )

            .checked;

        const success = await login(

            username,

            password,

            remember

        );

        if (

            success

        ) {

            if (

                typeof showToast ===

                "function"

            ) {

                showToast(

                    "Connexion réussie",

                    "success"

                );

            }

            setTimeout(

                () => {

                    window.location.href =

                        "index.html";

                },

                600

            );

            return;

        }

        throw new Error(

            "Identifiants invalides."

        );

    }

    catch (

        error

    ) {

        errorBox.textContent =

            error.message ||

            "Impossible de se connecter.";

        errorBox.classList.add(

            "active"

        );

        if (

            typeof showToast ===

            "function"

        ) {

            showToast(

                error.message ||

                "Erreur",

                "error"

            );

        }

    }

    finally {

        loader.style.display =

            "none";

        button.disabled =

            false;

    }

}


/*
==================================
TOGGLE PASSWORD
==================================
*/

function togglePassword() {

    const password =

        document.getElementById(

            "password"

        );

    const icon =

        document.querySelector(

            "#toggle-password i"

        );

    if (

        password.type ===

        "password"

    ) {

        password.type =

            "text";

        icon.setAttribute(

            "data-lucide",

            "eye-off"

        );

    }

    else {

        password.type =

            "password";

        icon.setAttribute(

            "data-lucide",

            "eye"

        );

    }

    if (

        window.lucide

    ) {

        lucide.createIcons();

    }

}